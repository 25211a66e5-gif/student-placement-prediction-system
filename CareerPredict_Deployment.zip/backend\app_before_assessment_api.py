from flask import Flask, request, jsonify
from flask_cors import CORS
from database import get_connection
from auth import hash_password, verify_password

import subprocess
import base64

app = Flask(__name__)
CORS(app)

TIMEOUT_SECONDS = 5
MAX_CODE_CHARS = 20000


# ============================================================
# CODING LANGUAGE CONFIGURATION
# ============================================================

LANGUAGE_CONFIG = {
    "Python": {
        "image": "python:3.12-alpine",
        "filename": "Main.py",
    },
    "Java": {
        "image": "eclipse-temurin:21-jdk-alpine",
        "filename": "Main.java",
    },
    "C++": {
        "image": "gcc:14",
        "filename": "Main.cpp",
    },
    "C": {
        "image": "gcc:14",
        "filename": "Main.c",
    },
    "JavaScript": {
        "image": "node:22-alpine",
        "filename": "Main.js",
    },
}


# ============================================================
# CODING TEST CASES
# ============================================================

TESTS = [
    {
        "input": "4\n4 9 2 7\n",
        "expected": "9"
    },
    {
        "input": "4\n-5 -2 -11 -1\n",
        "expected": "-1"
    },
    {
        "input": "3\n100 25 75\n",
        "expected": "100"
    },
    {
        "input": "1\n8\n",
        "expected": "8"
    }
]


# ============================================================
# DOCKER CODE EXECUTION
# ============================================================

def docker_run(language, code, stdin_data):

    config = LANGUAGE_CONFIG[language]

    code64 = base64.b64encode(code.encode()).decode()
    input64 = base64.b64encode(stdin_data.encode()).decode()

    filename = config["filename"]

    if language == "Python":

        runner = (
            f"cd /workspace && "
            f"echo {code64} | base64 -d > {filename} && "
            f"echo {input64} | base64 -d > /tmp/input.txt && "
            f"timeout 4s python {filename} < /tmp/input.txt"
        )

    elif language == "Java":

        runner = (
            f"cd /workspace && "
            f"echo {code64} | base64 -d > {filename} && "
            f"echo {input64} | base64 -d > /tmp/input.txt && "
            f"javac {filename} && "
            f"timeout 4s java Main < /tmp/input.txt"
        )

    elif language == "C++":

        runner = (
            f"cd /workspace && "
            f"echo {code64} | base64 -d > {filename} && "
            f"echo {input64} | base64 -d > /tmp/input.txt && "
            f"g++ {filename} -O2 -std=c++17 -o Main && "
            f"timeout 4s ./Main < /tmp/input.txt"
        )

    elif language == "C":

        runner = (
            f"cd /workspace && "
            f"echo {code64} | base64 -d > {filename} && "
            f"echo {input64} | base64 -d > /tmp/input.txt && "
            f"gcc {filename} -O2 -std=c11 -o Main && "
            f"timeout 4s ./Main < /tmp/input.txt"
        )

    else:

        runner = (
            f"cd /workspace && "
            f"echo {code64} | base64 -d > {filename} && "
            f"echo {input64} | base64 -d > /tmp/input.txt && "
            f"timeout 4s node {filename} < /tmp/input.txt"
        )

    cmd = [
        "docker",
        "run",
        "--rm",
        "-i",

        "--network",
        "none",

        "--memory",
        "128m",

        "--cpus",
        "0.5",

        "--pids-limit",
        "64",

        "--read-only",

        "--tmpfs",
        "/tmp:rw,nosuid,size=64m",

        "--tmpfs",
        "/workspace:rw,nosuid,size=64m",

        config["image"],

        "sh",
        "-c",
        runner
    ]

    try:

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=TIMEOUT_SECONDS + 3
        )

        return (
            result.returncode,
            result.stdout.strip(),
            result.stderr.strip()
        )

    except FileNotFoundError:

        return (
            -999,
            "",
            "Docker is not installed or is not available in PATH."
        )

    except subprocess.TimeoutExpired:

        return (
            -998,
            "",
            "Execution timed out."
        )


# ============================================================
# REGISTER
# ============================================================

@app.post("/api/register")
def register():

    data = request.get_json(silent=True) or {}

    first_name = str(data.get("first_name", "")).strip()
    last_name = str(data.get("last_name", "")).strip()
    email = str(data.get("email", "")).strip().lower()
    phone = str(data.get("phone", "")).strip()
    college = str(data.get("college", "")).strip()
    password = str(data.get("password", ""))

    if not first_name:
        return jsonify({
            "error": "First name is required."
        }), 400

    if not last_name:
        return jsonify({
            "error": "Last name is required."
        }), 400

    if not email:
        return jsonify({
            "error": "Email is required."
        }), 400

    if "@" not in email or "." not in email:

        return jsonify({
            "error": "Please enter a valid email address."
        }), 400

    if not phone:
        return jsonify({
            "error": "Phone number is required."
        }), 400

    if not college:
        return jsonify({
            "error": "College or university is required."
        }), 400

    if len(password) < 8:

        return jsonify({
            "error": "Password must contain at least 8 characters."
        }), 400

    connection = get_connection()

    try:

        cursor = connection.cursor()

        cursor.execute(
            "SELECT id FROM users WHERE email = ?",
            (email,)
        )

        existing_user = cursor.fetchone()

        if existing_user:

            return jsonify({
                "error": "An account with this email already exists."
            }), 409

        password_hash = hash_password(password)

        cursor.execute(
            """
            INSERT INTO users
            (
                first_name,
                last_name,
                email,
                phone,
                college,
                password_hash,
                role
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                first_name,
                last_name,
                email,
                phone,
                college,
                password_hash,
                "student"
            )
        )

        connection.commit()

        user_id = cursor.lastrowid

        return jsonify({

            "message": "Student account created successfully.",

            "user": {
                "id": user_id,
                "first_name": first_name,
                "last_name": last_name,
                "email": email,
                "role": "student"
            }

        }), 201

    except Exception as error:

        connection.rollback()

        return jsonify({
            "error": "Registration failed.",
            "message": str(error)
        }), 500

    finally:

        connection.close()


# ============================================================
# LOGIN
# ============================================================

@app.post("/api/login")
def login():

    data = request.get_json(silent=True) or {}

    email = str(data.get("email", "")).strip().lower()
    password = str(data.get("password", ""))

    if not email:

        return jsonify({
            "error": "Email is required."
        }), 400

    if not password:

        return jsonify({
            "error": "Password is required."
        }), 400

    connection = get_connection()

    try:

        cursor = connection.cursor()

        cursor.execute(
            """
            SELECT
                id,
                first_name,
                last_name,
                email,
                phone,
                college,
                password_hash,
                role
            FROM users
            WHERE email = ?
            """,
            (email,)
        )

        user = cursor.fetchone()

        if user is None:

            return jsonify({
                "error": "Invalid email or password."
            }), 401

        if not verify_password(
            password,
            user["password_hash"]
        ):

            return jsonify({
                "error": "Invalid email or password."
            }), 401

        return jsonify({

            "message": "Login successful.",

            "user": {
                "id": user["id"],
                "first_name": user["first_name"],
                "last_name": user["last_name"],
                "email": user["email"],
                "phone": user["phone"],
                "college": user["college"],
                "role": user["role"]
            }

        }), 200

    except Exception as error:

        return jsonify({
            "error": "Login failed.",
            "message": str(error)
        }), 500

    finally:

        connection.close()


# ============================================================
# SAVE / UPDATE STUDENT PROFILE
# ============================================================

@app.post("/api/profile")
def save_profile():

    data = request.get_json(silent=True) or {}

    user_id = data.get("user_id")

    # --------------------------------------------------------
    # USER ID
    # --------------------------------------------------------

    if not user_id:

        return jsonify({
            "error": "User ID is required."
        }), 400

    # --------------------------------------------------------
    # REQUIRED PROFILE FIELDS
    # --------------------------------------------------------

    tenth_percentage = data.get("tenth_percentage")
    twelfth_percentage = data.get("twelfth_percentage")
    cgpa = data.get("cgpa")
    graduation_year = data.get("graduation_year")
    backlogs = data.get("backlogs")

    branch = str(
        data.get("branch", "")
    ).strip()

    target_job_role = str(
        data.get("target_job_role", "")
    ).strip()

    technical_skills = str(
        data.get("technical_skills", "")
    ).strip()

    # --------------------------------------------------------
    # OPTIONAL PROFILE FIELDS
    # --------------------------------------------------------

    certifications = str(
        data.get("certifications", "")
    ).strip()

    projects = str(
        data.get("projects", "")
    ).strip()

    internships = str(
        data.get("internships", "")
    ).strip()

    github_url = str(
        data.get("github_url", "")
    ).strip()

    linkedin_url = str(
        data.get("linkedin_url", "")
    ).strip()

    portfolio_url = str(
        data.get("portfolio_url", "")
    ).strip()

    resume_url = str(
        data.get("resume_url", "")
    ).strip()

    # ========================================================
    # REQUIRED FIELD VALIDATION
    # ========================================================

    if tenth_percentage is None or str(tenth_percentage).strip() == "":
        return jsonify({
            "error": "10th percentage is required."
        }), 400

    if twelfth_percentage is None or str(twelfth_percentage).strip() == "":
        return jsonify({
            "error": "12th percentage is required."
        }), 400

    if cgpa is None or str(cgpa).strip() == "":
        return jsonify({
            "error": "B.Tech/B.E. CGPA is required."
        }), 400

    if graduation_year is None or str(graduation_year).strip() == "":
        return jsonify({
            "error": "Graduation year is required."
        }), 400

    if backlogs is None or str(backlogs).strip() == "":
        return jsonify({
            "error": "Current backlogs is required."
        }), 400

    if not branch:

        return jsonify({
            "error": "Engineering branch is required."
        }), 400

    if not target_job_role:

        return jsonify({
            "error": "Target job role is required."
        }), 400

    if not technical_skills:

        return jsonify({
            "error": "At least one technical skill is required."
        }), 400

    # ========================================================
    # NUMERIC VALIDATION
    # ========================================================

    try:

        tenth_percentage = float(
            tenth_percentage
        )

        twelfth_percentage = float(
            twelfth_percentage
        )

        cgpa = float(cgpa)

        graduation_year = int(
            graduation_year
        )

        backlogs = int(backlogs)

    except (ValueError, TypeError):

        return jsonify({
            "error": "Please enter valid academic values."
        }), 400

    # ========================================================
    # RANGE VALIDATION
    # ========================================================

    if tenth_percentage < 0 or tenth_percentage > 100:

        return jsonify({
            "error": "10th percentage must be between 0 and 100."
        }), 400

    if twelfth_percentage < 0 or twelfth_percentage > 100:

        return jsonify({
            "error": "12th percentage must be between 0 and 100."
        }), 400

    if cgpa < 0 or cgpa > 10:

        return jsonify({
            "error": "CGPA must be between 0 and 10."
        }), 400

    if backlogs < 0:

        return jsonify({
            "error": "Backlogs cannot be negative."
        }), 400

    # Graduation year validation
    if graduation_year < 2000 or graduation_year > 2100:

        return jsonify({
            "error": "Please enter a valid graduation year."
        }), 400

    # ========================================================
    # DATABASE
    # ========================================================

    connection = get_connection()

    try:

        cursor = connection.cursor()

        cursor.execute(
            "SELECT id FROM users WHERE id = ?",
            (user_id,)
        )

        user = cursor.fetchone()

        if user is None:

            return jsonify({
                "error": "Student account not found."
            }), 404

        cursor.execute(
            """
            SELECT id
            FROM student_profiles
            WHERE user_id = ?
            """,
            (user_id,)
        )

        existing_profile = cursor.fetchone()

        # ----------------------------------------------------
        # UPDATE EXISTING PROFILE
        # ----------------------------------------------------

        if existing_profile:

            cursor.execute(
                """
                UPDATE student_profiles
                SET
                    tenth_percentage = ?,
                    twelfth_percentage = ?,
                    cgpa = ?,
                    graduation_year = ?,
                    backlogs = ?,
                    branch = ?,
                    target_job_role = ?,
                    technical_skills = ?,
                    certifications = ?,
                    projects = ?,
                    internships = ?,
                    github_url = ?,
                    linkedin_url = ?,
                    portfolio_url = ?,
                    resume_url = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE user_id = ?
                """,
                (
                    tenth_percentage,
                    twelfth_percentage,
                    cgpa,
                    graduation_year,
                    backlogs,
                    branch,
                    target_job_role,
                    technical_skills,
                    certifications,
                    projects,
                    internships,
                    github_url,
                    linkedin_url,
                    portfolio_url,
                    resume_url,
                    user_id
                )
            )

            message = (
                "Student profile updated successfully."
            )

        # ----------------------------------------------------
        # CREATE NEW PROFILE
        # ----------------------------------------------------

        else:

            cursor.execute(
                """
                INSERT INTO student_profiles
                (
                    user_id,
                    tenth_percentage,
                    twelfth_percentage,
                    cgpa,
                    graduation_year,
                    backlogs,
                    branch,
                    target_job_role,
                    technical_skills,
                    certifications,
                    projects,
                    internships,
                    github_url,
                    linkedin_url,
                    portfolio_url,
                    resume_url
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    user_id,
                    tenth_percentage,
                    twelfth_percentage,
                    cgpa,
                    graduation_year,
                    backlogs,
                    branch,
                    target_job_role,
                    technical_skills,
                    certifications,
                    projects,
                    internships,
                    github_url,
                    linkedin_url,
                    portfolio_url,
                    resume_url
                )
            )

            message = (
                "Student profile created successfully."
            )

        connection.commit()

        return jsonify({

            "message": message,

            "profile": {
                "user_id": user_id,
                "branch": branch,
                "target_job_role": target_job_role
            }

        }), 200

    except Exception as error:

        connection.rollback()

        return jsonify({
            "error": "Unable to save profile.",
            "message": str(error)
        }), 500

    finally:

        connection.close()


# ============================================================
# GET STUDENT PROFILE
# ============================================================

@app.get("/api/profile/<int:user_id>")
def get_profile(user_id):

    connection = get_connection()

    try:

        cursor = connection.cursor()

        cursor.execute(
            """
            SELECT
                id,
                user_id,
                tenth_percentage,
                twelfth_percentage,
                cgpa,
                graduation_year,
                backlogs,
                branch,
                target_job_role,
                technical_skills,
                certifications,
                projects,
                internships,
                github_url,
                linkedin_url,
                portfolio_url,
                resume_url
            FROM student_profiles
            WHERE user_id = ?
            """,
            (user_id,)
        )

        profile = cursor.fetchone()

        if profile is None:

            return jsonify({
                "error": "Profile not found."
            }), 404

        return jsonify({
            "profile": dict(profile)
        }), 200

    except Exception as error:

        return jsonify({
            "error": "Unable to retrieve profile.",
            "message": str(error)
        }), 500

    finally:

        connection.close()


# ============================================================
# HEALTH CHECK
# ============================================================

@app.get("/api/health")
def health():

    return jsonify({
        "status": "ok",
        "service": "CareerPredict coding engine"
    })


# ============================================================
# RUN CODE
# ============================================================

@app.post("/api/run")
def run_code():

    data = request.get_json(silent=True) or {}

    language = str(
        data.get("language", "")
    ).strip()

    language_map = {
        "python": "Python",
        "java": "Java",
        "c++": "C++",
        "c": "C",
        "javascript": "JavaScript"
    }

    language = language_map.get(
        language.lower(),
        language
    )

    code = data.get("code", "")

    if language not in LANGUAGE_CONFIG:

        return jsonify({
            "error": "Unsupported language."
        }), 400

    if not code.strip():

        return jsonify({
            "error": "Code cannot be empty."
        }), 400

    if len(code) > MAX_CODE_CHARS:

        return jsonify({
            "error": "Code is too long."
        }), 400

    results = []
    passed = 0

    for i, test in enumerate(TESTS, 1):

        rc, output, error = docker_run(
            language,
            code,
            test["input"]
        )

        normalized = output.strip()

        if rc == -999:

            return jsonify({

                "error": "Coding engine unavailable.",

                "message": error,

                "setup": (
                    "Install Docker Desktop, "
                    "then run the backend again."
                )

            }), 503

        if rc == -998:

            results.append({
                "test": i,
                "passed": False,
                "message": "Time limit exceeded."
            })

            continue

        ok = (
            rc == 0
            and normalized == test["expected"]
        )

        if ok:
            passed += 1

        results.append({

            "test": i,

            "passed": ok,

            "expected": test["expected"],

            "received": normalized,

            "error": (
                error
                if rc != 0
                else ""
            )

        })

    score = round(
        passed / len(TESTS) * 100
    )

    return jsonify({

        "passed": passed,

        "total": len(TESTS),

        "score": score,

        "results": results

    })


# ============================================================
# START SERVER
# ============================================================

if __name__ == "__main__":

    app.run(
        host="127.0.0.1",
        port=5000,
        debug=True
    )